This directory contains several viral genomes, a lightweight taxonomy,
and a simple read simulator.  The genomes and taxonomy were obtained
from NCBI (with modifications to each to make a minimal filesize and
prepare them for Kraken 2 use).
