#include <algorithm>
#include <cctype>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <err.h>
#include <fcntl.h>
#include <sysexits.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include "omp_hack.h"

#ifndef SIZE_MAX
#define SIZE_MAX ((size_t) -1)
#endif

#ifndef UINT64_MAX
#define UINT64_MAX ((uint64_t) -1)
#endif
